<?php
add_action( 'woocommerce_before_single_product', 'prouductView', 99);

function prouductView(){
	global $pdpEvent;
	$pdpEvent->updateProductTracking(1); 
}



